int
main()
{
	printf("hello\n");
}
